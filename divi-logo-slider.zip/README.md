# divi logo-slider
Divi Module for Logo sliding
